﻿using System;

namespace ProvaEstagio
{
    class Program
    {
        public static void heapSort(int[] v)
        {
            constroiMaxHeap(v);
            int n = v.Length;

            for (int i = v.Length - 1; i > 0; i--)
            {
                troca(v, i, 0);
                refaz(v, 0, --n);
            }
        }

        private static void constroiMaxHeap(int[] v)
        {
            for (int i = v.Length / 2 - 1; i >= 0; i--)
                refaz(v, i, v.Length);

        }

        private static void refaz(int[] vetor, int pos, int tamanhoDoVetor)
        {

            int max = 2 * pos + 1, right = max + 1;
            if (max < tamanhoDoVetor)
            {

                if (right < tamanhoDoVetor && vetor[max] < vetor[right])
                    max = right;

                if (vetor[max] > vetor[pos])
                {
                    troca(vetor, max, pos);
                    refaz(vetor, max, tamanhoDoVetor);
                }
            }
        }

        public static void troca(int[] v, int j, int aposJ)
        {
            int aux = v[j];
            v[j] = v[aposJ];
            v[aposJ] = aux;
        }

        public static void Main(String[] args)
        {
            int[] a = { 1, 2, 4, 5, 7 };
            int[] b = { 2, 3, 5, 6, 10};
            int[] vetor = new int[10];


            for (int i = 0, cont = 0; i < vetor.Length; i++, cont++)
            {
                vetor[i] = a[cont];
                i++; 
                vetor[i] = b[cont];
                
            }

            heapSort(vetor);
            Console.WriteLine(String.Join(", ", vetor));
            Console.ReadKey();

        }
    }
}