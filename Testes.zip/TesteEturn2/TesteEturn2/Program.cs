﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesteEturn2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] vetor = { 1, 2, 3, 4, 5 };
            int maior1 = 0, maior2 = 0;
            int i = 0;

            for (i = 0; i < vetor.Length; i++)
            {
                if (vetor[i] > maior1)
                {
                   maior1 = vetor[i];
                }

            }
            for (i = 0; i < vetor.Length; i++)
            {
                if (vetor[i] < maior1 && maior2 < vetor[i])
                {
                    maior2 = vetor[i];
                }
                
            }
            Console.WriteLine(maior1);
            Console.WriteLine(maior2);
            Console.ReadKey();
        }
    }
}
