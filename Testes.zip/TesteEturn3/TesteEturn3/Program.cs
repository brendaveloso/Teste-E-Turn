﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace TesteEturn3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] vetor = { 33, 8, 88, 777, 66, 0, 9, 33, 22, 0, 33, 0, 7777, 666, 333, 8, 9, 2, 777, 33, 0, 7777, 666, 555, 88, 8, 444, 666, 66 };

            for (int i = 0; i < vetor.Length; i++)
            {
                if(vetor[i] == 0)
                {
                    Console.Write(' ');
                } 
                else if (vetor[i] == 2)
                {
                    Console.Write('A');
                }
                else if (vetor[i] == 22)
                {
                    Console.Write('B');
                }
                else if (vetor[i] == 33)
                {
                    Console.Write('E');
                }
                else if(vetor[i] == 333)
                {
                    Console.Write('F');
                }
                else if (vetor[i] == 444)
                {
                    Console.Write('I');
                }
                else if (vetor[i] == 555)
                {
                    Console.Write('L');
                }
                else if (vetor[i] == 66)
                {
                    Console.Write('N');
                }
                else if (vetor[i] == 666)
                {
                    Console.Write('O');
                }
                else if (vetor[i] == 777)
                {
                    Console.Write('R');
                }
                else if (vetor[i] == 7777)
                {
                    Console.Write('S');
                }
                else if (vetor[i] == 8)
                {
                    Console.Write('T');
                }
                else if (vetor[i] == 88)
                {
                    Console.Write('U');
                }
                else if (vetor[i] == 9)
                {
                    Console.Write('W');
                }
                
            }
            Console.ReadKey();
        }
    }
}
